package eecs2311.week3;

public class HelloWorld {
	public String say() { 
		return "Hello World!"; 
		}
}
