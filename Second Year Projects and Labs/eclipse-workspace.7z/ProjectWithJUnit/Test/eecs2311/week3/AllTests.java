package eecs2311.week3;


import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ HelloWorldTest.class }) 

public class AllTests {

}
