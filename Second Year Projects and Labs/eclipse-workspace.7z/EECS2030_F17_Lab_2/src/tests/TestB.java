package tests;

public class TestB {

}
