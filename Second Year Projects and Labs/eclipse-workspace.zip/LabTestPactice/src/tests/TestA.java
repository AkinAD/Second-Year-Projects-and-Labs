package tests;
import static org.junit.Assert.*;
import org.junit.Test;
import ltUtility.PracticeA;
public class TestA {
@Test
public  void testEmptyString(){
	//PracticeA A = new PracticeA();
}
}
